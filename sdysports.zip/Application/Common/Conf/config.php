<?php
return array(
	//'配置项'=>'配置值'
	

	//内容分类
	'TYPE_ARTICLE' => 0,    //所有文字展示型
	'TYPE_NORMAL' => 1,     //所有展示列表型
	'TYPE_SPECIAL' => 2,    //所有其他内容，如视频和定制页面
	
	//数据库配置
	'DB_TYPE' => 'mysql',
	'DB_HOST' => 'localhost',
	'DB_NAME' => 'sdysports',
	'DB_USER' => 'root',
	'DB_PWD'  => 'root',
	'DB_PREFIX' => ''
	
);
