<?php
return array(
    	'SHOW_PAGE_TRACE' => true
);
