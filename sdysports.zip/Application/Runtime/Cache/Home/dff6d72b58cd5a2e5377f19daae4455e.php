<?php if (!defined('THINK_PATH')) exit();?>
	<?php if(is_array($course)): $i = 0; $__LIST__ = $course;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
		<img src="<?php echo ($vo["path"]); ?>">
		<h1><?php echo ($vo["name"]); ?></h1>
		<?php echo ($vo["intro"]); ?>
		<a href="<?php echo U('showContent');?>?cid=<?php echo ($vo["cid"]); ?>" class="learn_more">了解详情</a>
	</li><?php endforeach; endif; else: echo "" ;endif; ?>