<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title><?php echo ($title); ?></title>
	<script type="text/javascript" src="/sdysports/Public/js/jquery.min.js"></script>
	<script type="text/javascript" src="/sdysports/Public/js/jquery.mousewheel-3.0.6.pack.js"></script>
	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="/sdysports/Public/source/jquery.fancybox.js?v=2.1.5"></script>
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/source/jquery.fancybox.css?v=2.1.5" media="screen" />
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/share.css">
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/common.css">
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/pagination.css">
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/member.css">
	<script type="text/javascript" src="/sdysports/Public/js/jquery.pagination.js"></script>
	<script type="text/javascript" src="/sdysports/Public/js/pics_page_divide.js"></script>
	<!--[if IE]>
	<script type="text/javascript" src="/sdysports/Public/js/html5.js"></script>
	<![endif]-->
	<script type="text/javascript">
	$(document).ready(function(){
		$('.fancybox').fancybox();
	})
	</script>
</head>
<body>
	<div id="fixed_bg"></div>
	<header>
		<nav>
			<img src="/sdysports/Public/images/logo.gif">
			<ul id="navbar">
				<li>
					<a href="<?php echo U('index');?>">首页</a>
				</li>
				<?php if(is_array($columns)): $i = 0; $__LIST__ = $columns;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; if(($vo['fid']) == "0"): ?><li>
				 <a href="<?php echo U('showContent');?>?cid=<?php echo ($vo["cid"]); ?>"><?php echo ($vo["name"]); ?></a>
				 <ul class="down_menu" >
				    <?php if(is_array($columns)): $i = 0; $__LIST__ = $columns;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$voc): $mod = ($i % 2 );++$i; if(($voc['fid']) == $vo['cid']): ?><li>
				        <a href="<?php echo U('showContent');?>?cid=<?php echo ($voc["cid"]); ?>"><?php echo ($voc["name"]); ?></a>
				    </li><?php endif; endforeach; endif; else: echo "" ;endif; ?>
				 </ul>
				</li><?php endif; endforeach; endif; else: echo "" ;endif; ?>
				<div style="clear:both;"></div>
			</ul>			
		</nav>
		<div id="nav2">
			<span id="indicator"><?php echo ($column['name']); ?></span>
			<ul>
				<li><a href="<?php echo U('showContent');?>?cid=<?php echo ($column['fc']['cid']); ?>"><?php echo ($column['fc']['name']); ?></a></li>
				<li><a href="<?php echo U('showContent');?>?cid=<?php echo ($column['cid']); ?>"><?php echo ($column['name']); ?></a></li>				
			</ul>
			<ul style="display:none;" id="hid"><li>/</li></ul>
		</div>		
	</header>

	<div id="main">
		<div id="splendid">
			<div id="wra_1">
				<div id="header_wra_1">
					<img src="<?php echo ($member1["pic"]); ?>">
					<h1><?php echo ($member1["name"]); ?></h1>
				</div>
				<p><?php echo ($member1["content"]); ?></p>
			</div>
			<div id="wra_2">				
				<p><?php echo ($member2["content"]); ?></p>
				<div id="header_wra_2">
					<img src="<?php echo ($member2["pic"]); ?>">
					<h1><?php echo ($member2["name"]); ?></h1>
				</div>
			</div>
		</div>
		<div id="hidden_result" style="display:none;"></div>
		<div id="show_wrap">			
			<div id="Pagination" class="pagination"></div>
			<h1>学员风采</h1>
			<div style="clear:both;"></div>
			<div id="show_box">			
				
			</div>
		</div>
	</div>
	<footer>
		<div id="sns">			
			<a href="http://weibo.com/u/5642419086" target="_blank" class="sns_weibo"></a>
			<a href="#" class="sns_weixin"></a>
	  		<div id="weixin_code"></div>
		</div>
	</footer>
</body>
<script type="text/javascript" src="/sdysports/Public/js/share.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		var nav2num = $('#nav2 li').length;
		console.log(nav2num);
		for(var i=1;i<nav2num;i++){
			$('#hid li').insertBefore($('#nav2 li').eq(i));
		}
	});
</script>
</html>

<input type="hidden" id="load" value="<?php echo U('showContent');?>?cid=<?php echo ($column["cid"]); ?>" />