<?php if (!defined('THINK_PATH')) exit();?>	<?php if(is_array($coach)): $i = 0; $__LIST__ = $coach;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
		<img src="<?php echo ($vo["pic"]); ?>">
		<div>
			<h1><?php echo ($vo["name"]); ?></h1>
			<h2 class="rank rank<?php echo ($vo["rank"]); ?>"></h2>
<?php echo ($vo["intro"]); ?>
		</div>	
	</li><?php endforeach; endif; else: echo "" ;endif; ?>