<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>思迪亚课程计划</title>
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/share.css">
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/common.css">
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/club.css">
	<!--[if IE]>
	<script type="text/javascript" src="/sdysports/Public/js/html5.js"></script>
	<![endif]-->
</head>
<body>
	<div id="fixed_bg"></div>
	
    	<header>
		<nav>
			<img src="/sdysports/Public/images/logo.gif">
			<ul id="navbar">
				<li>
					<a href="<?php echo U('index');?>">首页</a>
				</li>
				<?php if(is_array($columns)): $i = 0; $__LIST__ = $columns;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; if(($vo['fid']) == "0"): ?><li>
				 <a href="<?php echo U('showContent');?>?cid=<?php echo ($vo["cid"]); ?>"><?php echo ($vo["name"]); ?></a>
				 <ul class="down_menu" >
				    <?php if(is_array($columns)): $i = 0; $__LIST__ = $columns;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$voc): $mod = ($i % 2 );++$i; if(($voc['fid']) == $vo['cid']): ?><li>
				        <a href="<?php echo U('showContent');?>?cid=<?php echo ($voc["cid"]); ?>"><?php echo ($voc["name"]); ?></a>
				    </li><?php endif; endforeach; endif; else: echo "" ;endif; ?>
				 </ul>
				</li><?php endif; endforeach; endif; else: echo "" ;endif; ?>
				<div style="clear:both;"></div>
			</ul>			
		</nav>
		<div id="nav2">
			<span id="indicator"><?php echo ($column['name']); ?></span>
			<ul>
				<li><a href="<?php echo U('showContent');?>?cid=<?php echo ($column['fc']['cid']); ?>"><?php echo ($column['fc']['name']); ?></a></li>
				<li><a href="<?php echo U('showContent');?>?cid=<?php echo ($column['cid']); ?>"><?php echo ($column['name']); ?></a></li>				
			</ul>
			<ul style="display:none;" id="hid"><li>/</li></ul>
		</div>		
	</header>

    
	<div id="main">
		<h1>公司介绍</h1>
		<article>
			<img src="/sdysports/Public/images/big_logo.png">
			<p>思迪亚团队坚持以青少年体育教育为中心，以奋斗者为本，基于青少年成长需求持续创新，自主开发适合青少年德智体美全方发展的培训课程，通过实践赢得了众多学生及家长的青睐。在国内外同行业交流会上，我们独立创新的培训课程在体育培训机构中得到肯定。</p>
	      	<p>在青少年体育教育为核心基础上，我们放眼世界，2012年受到NBA中国的关注，帮助其在中国完成中国赛及篮球训练营等相关赛事及活动。与NBA中国良好合作背景下，我们还帮助 Adidas、Nike、李宁、匹克等国内外知名体育产业公司完成赛事活动，都获得了非常高的评价 。</p>
	      	<p>2015年思迪亚更是与西城区体育局育星俱乐部强强联手，不断突破，通过同北京体育大学，美国知名高校的不断交流研究，合力打造最适合中国青少年健康成长的篮球培训课程，真正做到体育，心理，文化共同发展的专属课程。</p>	      	
	    </article>
	</div>
	<footer>
		<div id="sns">			
			<a href="http://weibo.com/u/5642419086" target="_blank" class="sns_weibo"></a>
			<a href="#" class="sns_weixin"></a>
	  		<div id="weixin_code"></div>
		</div>
	</footer>
</body>
<script type="text/javascript" src="/sdysports/Public/js/share.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		var nav2num = $('#nav2 li').length;
		console.log(nav2num);
		for(var i=1;i<nav2num;i++){
			$('#hid li').insertBefore($('#nav2 li').eq(i));
		}
	});
</script>
</html>