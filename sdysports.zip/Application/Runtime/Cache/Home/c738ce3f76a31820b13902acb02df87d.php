<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">  
        <title>思迪亚后台管理系统 - 登录</title>
        <meta name="description" content="">
        <meta name="author" content="templatemo">

        <link href='http://fonts.useso.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
        <link href="/sdysports/Public/css/font-awesome.min.css" rel="stylesheet">
        <link href="/sdysports/Public/css/bootstrap.min.css" rel="stylesheet">
        <link href="/sdysports/Public/css/templatemo-style.css" rel="stylesheet">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="/sdysports/Public/js/html5shiv.min.js"></script>
        <script src="/sdysports/Public/js/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="light-gray-bg">
        <div class="templatemo-content-widget templatemo-login-widget white-bg">
            <header class="text-center">
                <div class="square"></div>
                <h1>思迪亚后台管理系统</h1>
            </header>
            <form action="<?php echo U('Admin/login');?>" method="post" class="templatemo-login-form">
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-user fa-fw"></i></div>	        		
                        <input type="text" name="username" class="form-control" placeholder="管理员账号">           
                    </div>	
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-addon"><i class="fa fa-key fa-fw"></i></div>	        		
                        <input type="password" name="password" class="form-control" placeholder="密码">           
                    </div>	
                </div>	          	
                <div class="form-group">
                    <button type="submit" class="templatemo-blue-button width-100">登录</button>
                </div>
            </form>
        </div>
    </body>
</html>