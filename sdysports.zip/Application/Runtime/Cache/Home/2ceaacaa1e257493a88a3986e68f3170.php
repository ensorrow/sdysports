<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title><?php echo ($title); ?></title>
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/share.css">
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/common.css">
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/coach.css">
	<link rel="stylesheet" type="text/css" href="/sdysports/Public/css/pagination.css">
	<script type="text/javascript" src="/sdysports/Public/js/jquery.min.js"></script>
	<script type="text/javascript" src="/sdysports/Public/js/share.js"></script>
	<script type="text/javascript" src="/sdysports/Public/js/jquery.pagination.js"></script>
	<script type="text/javascript" src="/sdysports/Public/js/coach_page_divide.js"></script>
	<!--[if IE]>
	<script type="text/javascript" src="/sdysports/Public/js/html5.js"></script>
	<![endif]-->
</head>
<body>
	<div id="fixed_bg"></div>
	<header>
		<nav>
			<img src="/sdysports/Public/images/logo.gif">
			<ul id="navbar">
				<li>
					<a href="<?php echo U('index');?>">首页</a>
				</li>
				<?php if(is_array($columns)): $i = 0; $__LIST__ = $columns;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; if(($vo['fid']) == "0"): ?><li>
				 <a href="<?php echo U('showContent');?>?cid=<?php echo ($vo["cid"]); ?>"><?php echo ($vo["name"]); ?></a>
				 <ul class="down_menu" >
				    <?php if(is_array($columns)): $i = 0; $__LIST__ = $columns;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$voc): $mod = ($i % 2 );++$i; if(($voc['fid']) == $vo['cid']): ?><li>
				        <a href="<?php echo U('showContent');?>?cid=<?php echo ($voc["cid"]); ?>"><?php echo ($voc["name"]); ?></a>
				    </li><?php endif; endforeach; endif; else: echo "" ;endif; ?>
				 </ul>
				</li><?php endif; endforeach; endif; else: echo "" ;endif; ?>
				<div style="clear:both;"></div>
			</ul>			
		</nav>
		<div id="nav2">
			<span id="indicator"><?php echo ($column['name']); ?></span>
			<ul>
				<li><a href="<?php echo U('showContent');?>?cid=<?php echo ($column['fc']['cid']); ?>"><?php echo ($column['fc']['name']); ?></a></li>
				<li><a href="<?php echo U('showContent');?>?cid=<?php echo ($column['cid']); ?>"><?php echo ($column['name']); ?></a></li>				
			</ul>
			<ul style="display:none;" id="hid"><li>/</li></ul>
		</div>		
	</header>

	<div id="main">
		<ul id="list" class="m-pagination">

		</ul>
		<ul id="hidden_result" style="display:none;"></ul>
		<div id="Pagination" class="pagination"></div>
	</div>
	<footer>
		<div id="sns">			
			<a href="http://weibo.com/u/5642419086" target="_blank" class="sns_weibo"></a>
			<a href="#" class="sns_weixin"></a>
	  		<div id="weixin_code"></div>
		</div>
	</footer>
</body>
<script type="text/javascript" src="/sdysports/Public/js/share.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		var nav2num = $('#nav2 li').length;
		console.log(nav2num);
		for(var i=1;i<nav2num;i++){
			$('#hid li').insertBefore($('#nav2 li').eq(i));
		}
	});
</script>
</html>

<input type="hidden" id="load" value="<?php echo U('showContent');?>?cid=<?php echo ($column["cid"]); ?>"/>