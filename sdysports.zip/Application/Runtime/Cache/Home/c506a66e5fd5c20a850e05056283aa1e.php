<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">  
        <title>思迪亚后台管理</title>
        <meta name="description" content="">
        <meta name="author" content="templatemo">

        <link href='http://fonts.useso.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
        <link href="/sdysports/Public/css/font-awesome.min.css" rel="stylesheet">
        <link href="/sdysports/Public/css/bootstrap.min.css" rel="stylesheet">
        <link href="/sdysports/Public/css/templatemo-style.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="/sdysports/Public/css/admin_common.css">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="/sdysports/Public/js/html5shiv.min.js"></script>
        <script src="/sdysports/Public/js/respond.min.js"></script>
        <![endif]-->

    </head>
    <body>  
        <!-- Left column -->
        <div class="templatemo-flex-row">
            <div class="templatemo-sidebar">
                <header class="templatemo-site-header">
                    <div class="square"></div>
                    <h1>思迪亚体育联盟</h1>
                </header>
                <div class="profile-photo-container">
                    <img src="/sdysports/Public/images/profile-photo.jpg" alt="Profile Photo" class="img-responsive">  
                    <div class="profile-photo-overlay"></div>
                </div>      
                <!-- Search box -->
                <form class="templatemo-search-form" role="search">
                    <div class="input-group">
                        <button type="submit" class="fa fa-search"></button>
                        <input type="text" class="form-control" placeholder="Search" name="srch-term" id="srch-term">           
                    </div>
                </form>
                <div class="mobile-menu-icon">
                    <i class="fa fa-bars"></i>
                </div>
                <nav class="templatemo-left-nav">          
                    <ul>
                        <li><a href="#" class="active"><i class="fa fa-home fa-fw"></i>首页</a></li>
                        <li><a href="course-plan.html"><i class="fa fa-bar-chart fa-fw"></i>课程计划</a></li>
                        <li><a href="excellent.html"><i class="fa fa-database fa-fw"></i>优秀学员</a></li>
                        <li><a href="<?php echo U('editVideo');?>"><i class="fa fa-map-marker fa-fw"></i>视频发布</a></li>
                        <li><a href="<?php echo U('editArticle');?>"><i class="fa fa-map-marker fa-fw"></i>新闻发布</a></li>
                        
                        <li><a href="<?php echo U('logout');?>"><i class="fa fa-eject fa-fw"></i>退出登录</a></li>
                    </ul>  
                </nav>
            </div>
            <!-- Main content --> 
            <div class="templatemo-content col-1 light-gray-bg">
                <div class="templatemo-top-nav-container">
                    <div class="row">
                        <nav class="templatemo-top-nav col-lg-12 col-md-12">
                            <ul class="text-uppercase">
                                <li><a href="<?php echo U('Admin/index');?>" class="active">后台管理</a></li>
                                <li><a href="<?php echo U('Index/index');?>">网站首页</a></li>
                            </ul>
                            <span id="user_head"></span>  
                        </nav> 
                    </div>
                </div>
                <div class="templatemo-content-container">
                    <div class="templatemo-flex-row flex-content-row">
                       
                                                <div class="col-1">
                            <div class="panel panel-default templatemo-content-widget white-bg no-padding templatemo-overflow-hidden">
                                <i class="fa fa-times"></i>
                                <div class="panel-heading templatemo-position-relative">
                                    <h2 class="text-uppercase">栏目列表</h2>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <td>编号</td>
                                                <td>栏目名</td>
                                                <td>管理页面</td>
                                                <td>删除栏目</td>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(is_array($column)): $i = 0; $__LIST__ = $column;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
                                                <td><?php echo ($vo["cid"]); ?></td>
                                                <td><?php echo ($vo["name"]); ?></td>
                                                <td><a href="<?php echo U('edit');?>?cid=<?php echo ($vo["cid"]); ?>" >进入管理页面</a></td>
                                                <td><a href="<?php echo U('delete');?>?cid=<?php echo ($vo["cid"]); ?>" >删除</a></td>
                                            </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                                            <tr>
                                                <form method="post" id="sform" action="<?php echo U('editColumn');?>">
                                                    <td>新增</td>
                                                    <td><input type="text" name="name" /></td>
                                                    <td><input type="" /></td>
                                                    <td><a class="zhuce" href="#" name="submit" onclick="document.getElementById('sform').submit();return false" >提交</a></td>
                                                </form>
                                            </tr>
                                        </tbody>
                                    </table>    
                                </div>                          
                            </div>
                        </div> 
                    </div> <!-- Second row ends -->
                    <footer class="text-right">
                        <p>Copyright &copy; 2084 Company Name 
                            | More Templates <a href="http://www.mycodes.net/" target="_blank">源码之家</a></p>
                    </footer>         
                </div>
            </div>
        </div>

        <!-- JS -->
        <script src="/sdysports/Public/js/jquery-1.11.2.min.js"></script>      <!-- jQuery -->
        <script src="/sdysports/Public/js/jquery-migrate-1.2.1.min.js"></script> <!--  jQuery Migrate Plugin -->
        <script type="text/javascript" src="/sdysports/Public/js/templatemo-script.js"></script>      <!-- Templatemo Script -->

    </body>
</html>