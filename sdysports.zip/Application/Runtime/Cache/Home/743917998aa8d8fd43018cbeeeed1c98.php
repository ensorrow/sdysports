<?php if (!defined('THINK_PATH')) exit();?>
	<?php if(is_array($vList)): $i = 0; $__LIST__ = $vList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
		<h4 class="float_icon"><?php echo (date("M",$vo["time"])); ?><span><?php echo (date("d",$vo["time"])); ?></span></h4>
		<img src="/sdysports/Public/images/videotype.png" class="float_icon">
		<div class="video_wrap">
			<video src="<?php echo ($vo["path"]); ?>" width="553" height="350" controls autobuffer>请升级你的浏览器！（如谷歌浏览器，火狐浏览器，360浏览器！）</video>
		</div>
		<h1><?php echo ($vo["title"]); ?></h1>
		<span class="times"><?php echo ($vo["hit"]); ?></span>
		<h2>新手在场上如何做好防守？最后三分钟应如何调节心态？如何避免被绝杀?</h2>
	</li><?php endforeach; endif; else: echo "" ;endif; ?>